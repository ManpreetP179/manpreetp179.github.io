#SERvER

#install
npm install express firebase dotenv cors morgan 
npm i cookie-parser method-override morgan path cors body-parser knex cors morgan pg express
npm i nodemon -D
npm i objection -D
npm i react-bootstrap
npm i bootstrap

npm i body-parser

npm i firebase-tools
#read this document to refer about firebases

**RESET DATABASE for mac (not sure about the other linux)
psql -U postgres -h 127.0.0.1 -c 'DROP DATABASE IF EXISTS shopping_cart;'

**database references
https://www.youtube.com/watch?v=zbIl2kuP7tE&t=338s
https://github.com/productioncoder/objection-js-tutorial/blob/main/db/models/channel.js
https://github.com/KritikaSharmaKS/Objection-Youtube/tree/main/util
https://github.com/KritikaSharmaKS/Objection-Youtube/blob/main/models/customer.js

**login express
https://www.loginradius.com/blog/engineering/hashing-user-passwords-using-bcryptjs/

things to do


